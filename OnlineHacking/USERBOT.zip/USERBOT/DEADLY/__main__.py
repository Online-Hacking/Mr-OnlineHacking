
import config
import asyncio
from pyrogram import idle
from DEADLY import bot1, bot2, bot3, bot4, bot5, bot6, bot7, bot8, bot9, bot10

OWNER_ID = "GitExpert"

if bot1:
    bot1.start()
    bot1.join_chat("deadly_spambot")
if bot2:
    bot2.start()
    bot2.join_chat("deadly_spambot")
if bot3:
    bot3.start()
    bot3.join_chat("deadly_spambot")
if bot4:
    bot4.start()
    bot4.join_chat("deadly_spambot")
if bot5:
    bot5.start()
    bot5.join_chat("deadly_spambot")
if bot6:
    bot6.start()
    bot6.join_chat("deadly_spambot")
if bot7:
    bot7.start()
    bot7.join_chat("deadly_spambot")
if bot8:
    bot8.start()
    bot8.join_chat("deadly_spambot")
if bot9:
    bot9.start()
    bot9.join_chat("deadly_spambot")
if bot10:
    bot10.start()
    bot10.join_chat("deadly_spambot")

print("Your UserSpam Userbot Deployed Successfully 🥳 Please visit @suman333mondal for any help!") 

idle()
